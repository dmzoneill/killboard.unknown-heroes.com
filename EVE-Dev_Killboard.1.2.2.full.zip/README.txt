This is the EDK - EVE Development Network Killboard v1.2

Check out the EVE-Development Network for support, 
bugfixes and new versions at www.eve-dev.net...
Developers wanted!
If you'd like to contibute to further version of this killboard, sign up for the EVE-Dev forums!

Requirements:

- Webserver (apache)
- PHP 4.0.9+
- Mysql 3.23.+
- GD 2 or higher

Setup:

- Upload the whole package to a webhost
- Point your webbrowser to /install inside the EDK-Directory
- Follow the instructions
- Have fun ;)


o/ EVE Development Network