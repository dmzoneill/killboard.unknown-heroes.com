<?php
error_reporting(E_ALL ^ E_NOTICE);
include('common/index.php');
?>
