CREATE TABLE `kb3_inv_all` (
  `ina_kll_id` int(6) NOT NULL default '0',
  `ina_all_id` int(3) NOT NULL default '0',
  KEY `ina_all_id` (`ina_all_id`)
) TYPE=MyISAM;