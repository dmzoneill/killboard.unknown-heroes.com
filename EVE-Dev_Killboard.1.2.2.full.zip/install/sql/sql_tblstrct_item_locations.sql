CREATE TABLE `kb3_item_locations` (
  `itl_id` int(11) NOT NULL auto_increment,
  `itl_location` varchar(24) NOT NULL default '',
  PRIMARY KEY  (`itl_id`)
) TYPE=MyISAM;