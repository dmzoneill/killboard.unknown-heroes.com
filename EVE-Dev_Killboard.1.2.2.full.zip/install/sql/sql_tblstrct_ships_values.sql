CREATE TABLE `kb3_ships_values` (
  `shp_id` int(11) NOT NULL,
  `shp_value` bigint(4) NOT NULL,
  PRIMARY KEY  (`shp_id`)
) TYPE=MyISAM;