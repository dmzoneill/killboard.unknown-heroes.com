CREATE TABLE `kb3_constellations` (
  `con_id` int(11) NOT NULL default '0',
  `con_name` varchar(128) NOT NULL default '',
  `con_reg_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`con_id`)
) TYPE=MyISAM;