CREATE TABLE `kb3_inv_crp` (
  `inc_kll_id` int(6) NOT NULL default '0',
  `inc_crp_id` int(6) NOT NULL default '0',
  KEY `inc_crp_id` (`inc_crp_id`)
) TYPE=MyISAM;