CREATE TABLE `kb3_races` (
  `rce_id` int(11) NOT NULL auto_increment,
  `rce_race` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`rce_id`)
) TYPE=MyISAM;