TRUNCATE TABLE `kb3_races`;
INSERT IGNORE INTO `kb3_races` VALUES ('1','Gallente');
INSERT IGNORE INTO `kb3_races` VALUES ('2','Caldari');
INSERT IGNORE INTO `kb3_races` VALUES ('3','Amarr');
INSERT IGNORE INTO `kb3_races` VALUES ('4','Minmatar');
