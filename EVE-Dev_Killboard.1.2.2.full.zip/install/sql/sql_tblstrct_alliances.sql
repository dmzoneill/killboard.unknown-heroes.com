CREATE TABLE `kb3_alliances` (
  `all_id` int(11) NOT NULL auto_increment,
  `all_name` varchar(64) NOT NULL default '',
  PRIMARY KEY  (`all_id`)
) TYPE=MyISAM;