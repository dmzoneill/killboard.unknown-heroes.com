CREATE TABLE `kb3_inv_plt` (
  `inp_kll_id` int(6) NOT NULL default '0',
  `inp_plt_id` int(6) NOT NULL default '0',
  KEY `inp_plt_id` (`inp_plt_id`)
) TYPE=MyISAM;