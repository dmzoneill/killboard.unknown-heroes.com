<p>Welcome to the new installer, it will help you to set up everything correctly.<br/>
The next step will test if your server has the needed modules to run the Killboard with all features.
</p>

<p><a href="?step=<?php echo ($_SESSION['state']+1); ?>">Next Step</a></p>