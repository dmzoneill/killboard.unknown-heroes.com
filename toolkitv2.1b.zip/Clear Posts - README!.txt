NOTICE: The "Clear Posts" option does NOT remove the posts themselves!

There has been alot of confusion about what happens in v2.1b
of the toolkit when you choose the "Clear Posts" option when
removing a user. So let me explain the results that occur when the "Clear Posts"
option is selected when deleting a user.

This option was made as a middle-step to combat spam posters. Normally, even if you remove
a user, all fo their posts are still left with their spam. The toolkit's clear posts option
was created to  "clear" the spam from the board so all the porn/advertisement links and
messages are removed. 

When a user is deleted via the toolkit, is removed from the database exactly the same way
as it would be in phpBB. However, when the clear posts option is checked the toolkit
performs two extra steps:

	1. It replaces the topic title of any topic posted by that user to the word "DELETED"
	2. It replaces the text within all their posts to the word "DELETED"

When the "clear posts" option is checked, the posts are still physically left behind, but
they no longer contain the spam information. They are essentially "empty" topics.

When I wrote this function I assumed that would be more then enough for most administrators,
as they could simply go back into phpbb and delete the "DELETED" posts that remain.
However, ever since releasing v2.1 which included this function, I have received numerous
requests to remove the posts in their entirety, not just replacing the text.

I am working on v2.2 which will include such a feature. If you would like to receive a
notification when this version is released you can register on the toolkit support forums.